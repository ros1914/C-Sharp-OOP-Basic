﻿namespace _0._5_Mordor_s_Cruelty_Plan.FoodModels
{
	public class Apple : Food
	{
		private const int HappinesPoints = 1;

		public Apple() : base (HappinesPoints)
		{

		}
	}
}
