﻿namespace _0._5_Mordor_s_Cruelty_Plan
{
	public class Cram : Food
	{
		private const int point = 2;

		public Cram() : base(point)
		{

		}
	}
}
