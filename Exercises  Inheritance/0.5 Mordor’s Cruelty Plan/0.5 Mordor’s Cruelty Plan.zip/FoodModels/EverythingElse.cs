﻿namespace _0._5_Mordor_s_Cruelty_Plan.FoodModels
{
	public class EverythingElse : Food
	{
		private const int point = -1;

		public EverythingElse() : base(point)
		{
		}

	}
}
