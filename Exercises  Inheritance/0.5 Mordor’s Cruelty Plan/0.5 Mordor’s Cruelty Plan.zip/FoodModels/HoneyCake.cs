﻿namespace _0._5_Mordor_s_Cruelty_Plan.FoodModels
{
	public class HoneyCake : Food
	{
		private const int point = 5;

		public HoneyCake() : base(point)
		{
		}
	}
}
