﻿namespace _0._5_Mordor_s_Cruelty_Plan.FoodModels
{
	public class Lembas : Food
	{
		private const int points = 3;

		public Lembas(): base(points)
		{

		}
	}
}
