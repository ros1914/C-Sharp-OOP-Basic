﻿namespace _0._5_Mordor_s_Cruelty_Plan.FoodModels
{
	public class Melon : Food
	{
		private const int point = 1;

		public Melon() : base(point)
		{

		}
	}
}
