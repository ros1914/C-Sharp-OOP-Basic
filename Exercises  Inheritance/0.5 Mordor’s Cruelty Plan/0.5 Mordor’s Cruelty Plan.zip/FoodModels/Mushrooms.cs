﻿namespace _0._5_Mordor_s_Cruelty_Plan.FoodModels
{
	public  class Mushrooms : Food
	{
		private const int point = -10;
		public Mushrooms() : base(point)
		{

		}
	}
}
