﻿namespace _0._5_Mordor_s_Cruelty_Plan.MoodModels
{
	public class Angry : Mood
	{
		private const string name = "Angry";

		public Angry() : base(name)
		{

		}
	}
}
