﻿namespace _0._5_Mordor_s_Cruelty_Plan.MoodModels
{
	public class JavaScript : Mood
	{
		private const string name = "JavaScript";

		public JavaScript() : base(name)
		{

		}
	}
}
