﻿namespace _0._5_Mordor_s_Cruelty_Plan.MoodModels
{
	public class Sad : Mood
	{
		private const string name = "Sad";

		public Sad() : base(name)
		{

		}
	}
}
