﻿namespace _03.WildFarm
{
	public class Meat : Food
	{
		public Meat(int quantity) : base(quantity)
		{
		}
	}
}
